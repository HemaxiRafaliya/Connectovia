// document.addEventListener("DOMContentLoaded", function () {
//     let currentIndex = 0;
//     const slides = document.querySelectorAll('.slider-slide');
//     const totalSlides = slides.length;
//     const sliderWrapper = document.querySelector('.slider-wrapper');
  
//     function showImage(index) {
//       if (index >= totalSlides) {
//         currentIndex = 0;
//       } else if (index < 0) {
//         currentIndex = totalSlides - 1;
//       } else {
//         currentIndex = index;
//       }
//       sliderWrapper.style.transform = `translateX(-${currentIndex * 100}vw)`;
//     }
  
//     setInterval(() => {
//       showImage(currentIndex + 1);
//     }, 2000);
//   });
//   let currentIndex = 0;
// const slides = document.querySelectorAll('.slider-slide');
// const totalSlides = slides.length;
// const sliderWrapper = document.querySelector('.slider-wrapper');

// function showImage(index) {
//   if (index >= totalSlides) {
//     currentIndex = 0;
//   } else if (index < 0) {
//     currentIndex = totalSlides - 1;
//   } else {
//     currentIndex = index;
//   }

//   sliderWrapper.style.transform = `translateX(-${currentIndex * 100}vw)`;
// }

// // Autoplay
// setInterval(() => {
//   showImage(currentIndex + 1);
// }, 4000);

// // Buttons
// document.getElementById("prevBtn").addEventListener("click", () => {
//   showImage(currentIndex - 1);
// });

// document.getElementById("nextBtn").addEventListener("click", () => {
//   showImage(currentIndex + 1);
// });


document.addEventListener("DOMContentLoaded", function () {
  let currentIndex = 0;
  const slides = document.querySelectorAll('.slider-slide');
  const totalSlides = slides.length;
  const sliderWrapper = document.querySelector('.slider-wrapper');

  // Set initial styles for smooth sliding
  sliderWrapper.style.display = "flex";
  sliderWrapper.style.transition = "transform 0.5s ease-in-out";
  sliderWrapper.style.width = `${totalSlides * 100}vw`;

  slides.forEach(slide => {
    slide.style.flex = "0 0 100vw";
  });

  function showImage(index) {
    currentIndex = index;

    // Smooth transition until the last slide
    if (index < totalSlides) {
      sliderWrapper.style.transform = `translateX(-${currentIndex * 100}vw)`;
    }

    // After the last slide, reset smoothly to the first
    if (index === totalSlides) {
      setTimeout(() => {
        sliderWrapper.style.transition = "none"; // remove transition
        sliderWrapper.style.transform = `translateX(0)`;
        currentIndex = 0;
      }, 500); // match the transition duration

      setTimeout(() => {
        sliderWrapper.style.transition = "transform 0.5s ease-in-out";
      }, 600);
    }
  }

  // Auto-slide every 4 seconds
  setInterval(() => {
    showImage(currentIndex + 1);
  }, 4000);
});

